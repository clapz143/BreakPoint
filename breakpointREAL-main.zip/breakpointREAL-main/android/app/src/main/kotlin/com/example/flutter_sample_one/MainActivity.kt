package com.example.flutter_sample_one

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
